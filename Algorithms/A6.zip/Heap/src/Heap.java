import java.util.*;

public class Heap {
  private ArrayList<Integer> list;

  // constructor
  public Heap() {
    list = new ArrayList<Integer>();
  }
  
  public void enqueue(int entry) {
    list.add(entry);
    reheapifyUp(list.size()-1);
  }
  
  public int dequeue() {
    int root = list.get(0); //store root element in a temp variable
    list.set(0, list.get(list.size()-1));
    list.remove(list.size()-1);
    reheapifyDown(0); //the new root element down the tree
    return root;
  }
  
  public int size() {
    return list.size();
  }
  
  private void reheapifyUp(int currentSpot) {
    int parent = (currentSpot-1)/2;
    int newElement = list.get(currentSpot);
    while (newElement != list.get(0) && list.get(currentSpot) > list.get(parent)) {
      Collections.swap(list, currentSpot, parent);
      currentSpot = parent;
      parent = (currentSpot-1)/2;
    }
    
  }
  
  private void reheapifyDown(int currentSpot) {
    int leftChild = currentSpot*2+1;
    int rightChild = currentSpot*2+2;
    while (leftChild < size()) {
      int largest; //find largest of two children
      if (rightChild < size() && list.get(leftChild) < list.get(rightChild)) {
        largest = rightChild;
      }
      else {
        largest = leftChild;
      }
      if (list.get(currentSpot) >= list.get(largest)) {
        break; // key is >= children, can stop
      }
      // swap currentSpot and largest child elements
      Collections.swap(list, currentSpot, largest);
      currentSpot = largest;
      leftChild = currentSpot*2+1; //children indices
      rightChild = currentSpot*2+2; //children indices
    }
  }
  
  public void heapSort(ArrayList<Integer> data) {
    list = data;
    for (int i = 0; i < size(); ++i) {
      reheapifyUp(i);
    }
    int unsorted = size();
    while (unsorted > 1) {
      Collections.swap(list, 0, unsorted-1);
      partialReheapifyDown(0, unsorted-1);
      unsorted--;
    }
  }
  
  private void partialReheapifyDown(int currentSpot, int stop) {
    int leftChild = currentSpot*2+1;
    int rightChild = currentSpot*2+2;
    while (leftChild < stop) {
      int largest;
      if (rightChild < stop && list.get(leftChild) < list.get(rightChild)) {
        largest = rightChild;
      }
      else {
        largest = leftChild;
      }
      if (list.get(currentSpot) >= list.get(largest)) {
        break;
      }
      // swap currentSpot and largest child elements
      Collections.swap(list, currentSpot, largest);
      currentSpot = largest;
      leftChild = currentSpot*2+1; //children indices
      rightChild = currentSpot*2+2; //children indices
    }
  }
  
  public static void main(String args[]) {
    Random random = new Random();
    ArrayList<Integer> list = new ArrayList<Integer>();
    for(int i = 0; i < 100; i++) {
      list.add(random.nextInt(100*10));
    }
    Heap heap = new Heap();
    heap.heapSort(list);
    
    System.out.print("{");
    for (int i = 0; i < list.size(); ++i)
      System.out.print(list.get(i) + " ");
    System.out.println("}");
  }

}
