import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

public class SearchNSortDriver {
  public static void main(String[] args) {
    int n = 100;
    Random random = new Random();
    ArrayList<Integer> list = new ArrayList<Integer>();
    for (int i = 0; i < n; i++) {
      list.add(random.nextInt(n*10));
    }
    
    SearchAndSortAlgorithms sasa = new SearchAndSortAlgorithms();
    
    int indexOfValue = sasa.sequentialSearch(list,  list.get(0));
    
    if (indexOfValue == 0)
      System.out.println("Yes we found it at " + indexOfValue);
    else
      System.out.println("Expected index 0 and got " + indexOfValue);
    System.out.println("Not sorted");
    sasa.printArrayList(list);
    Collections.sort(list);
    System.out.println("\nSorted:");
    sasa.printArrayList(list);
    System.out.println("-----------------------------------------------------");
    System.out.println("binarySearchRecursive:");
    int testNum = list.get(5);
    System.out.println("Test number: " + list.get(5));
    System.out.println("Location: " + sasa.binarySearchIterative(list, testNum));
    
    System.out.println("------------------------");
    System.out.println("binarySearchIterative:");
    System.out.println("Test num: " + testNum);
    System.out.println("Location: " + sasa.binarySearchIterative(list, testNum));
    
    System.out.println("-----------------------------------");
    System.out.println("insertionSort:");
    
    ArrayList<Integer> list1 = new ArrayList<Integer>();
    for (int i = 0; i < n; i++) {
      list1.add(random.nextInt(n*10));
    }
    System.out.println("Before insertion sort: ");
    System.out.println(list1);
    System.out.println("After insertion sort:");
    sasa.insertionSort(list1);
    System.out.println(list1);
    
    System.out.println("Quicksort:");
    ArrayList<Integer> list2 = new ArrayList<Integer>();
    for (int i = 0; i < n; i++) {
      list2.add(random.nextInt(n*10));
    }
    System.out.println("Before quicksort:");
    System.out.println(list2);
    sasa.quickSort(list2, 0, list2.size()-1);
    System.out.println("After quicksort:");
    System.out.println(list2);
  }

}
