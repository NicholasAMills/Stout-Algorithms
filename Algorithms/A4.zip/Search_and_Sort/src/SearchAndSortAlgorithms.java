import java.util.ArrayList;
import java.util.Collections;

public class SearchAndSortAlgorithms implements SearchableAndSortable {

  @Override
  public int sequentialSearch(ArrayList<Integer> A, int K) {
    // TODO Auto-generated method stub
    return 0;
  }

  @Override
  public int binarySearchRecursive(ArrayList<Integer> data, int value, int low, int high) {
    // TODO Auto-generated method stub
    if (high < low) return -1;
    int mid = (low + high) / 2;
    if (data.get(mid) > value) 
      return binarySearchRecursive(data, value, low, mid-1);
    else if (data.get(mid) < value) {
      return binarySearchRecursive(data, value, mid+1, high);
    }
    else
      return mid;
  }

  @Override
  public int binarySearchIterative(ArrayList<Integer> data, int value) {
    // TODO Auto-generated method stub
    int low = 0;
    int high = data.size() - 1;
    while (low <= high) {
      int mid = (low + high) / 2;
      if (data.get(mid) > value)
        high = mid - 1;
      else if (data.get(mid) < value)
        low = mid + 1;
      else 
        return mid;
    }
    return -1;
  }

  @Override
  public void insertionSort(ArrayList<Integer> A) {
    // TODO Auto-generated method stub
    for (int i = 1; i < A.size(); ++i) {
      int v = A.get(i);
      int j = i - 1;
      
      while (j >= 0 && A.get(j) > v) {
        A.set(j+1, A.get(j));
        j--;
      }
      A.set(j + 1, v);
    }
  }

  @Override
  public void quickSort(ArrayList<Integer> A, int low, int high) {
    // TODO Auto-generated method stub
    if (low < high) {
      int pi = partition(A, low, high);
      
      quickSort(A, low, pi-1); // before pi
      quickSort(A, pi + 1, high); // after pi
    }

  }

  @Override
  public int partition(ArrayList<Integer> A, int left, int right) {
    // TODO Auto-generated method stub
    int p = A.get(left);
    int i = left, j = right + 1;
    
    do {
      do {
        i++;
      } while (A.get(i) < p && i < right);
      do {
        j--;
      } while (A.get(j) > p && j > left);
      
      Collections.swap(A, i, j);
    } while (i < j);
    
      Collections.swap(A, i, j);

      Collections.swap(A, left, j);

    return j;
  }

  @Override
  public void printArrayList(ArrayList<Integer> data) {
    // TODO Auto-generated method stub
    for (int i=0; i < data.size(); i++) {
      System.out.print(data.get(i) + " ");
      if (i%100==0 && i > 0)
         System.out.println();
    }

  }

}
